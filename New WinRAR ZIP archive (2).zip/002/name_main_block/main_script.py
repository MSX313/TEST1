# Importing the module
import module_example

# This code will run when the module is imported
print("Main script is running!")

# Calling a function from the imported module
module_example.my_function()

# *********out put *************************
# Module is imported!
# Main script is running!
# Hello from my_function!
# *********out put *************************