# This code will run when the module is imported
print("Module is imported!")

def my_function():
    print("Hello from my_function!")

# Check if the script is the main program
if __name__ == "__main__":
    # This code will only run if the module is executed directly
    print("Module is executed directly!")
    my_function()
