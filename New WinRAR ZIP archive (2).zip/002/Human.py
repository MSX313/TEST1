class Human:
    def __init__(self):
        self._first_name = None
        self._last_name = None
        self._age = None
        self._national_code = None

    @property
    def first_name(self):
        return self._first_name

    @first_name.setter
    def first_name(self, first_name):
        self._first_name = first_name

    @property
    def last_name(self):
        return self._last_name

    @last_name.setter
    def last_name(self, last_name):
        self._last_name = last_name

    @property
    def age(self):
        return self._age

    @age.setter
    def age(self, age):
        self._age = age

    @property
    def national_code(self):
        return self._national_code

    @national_code.setter
    def national_code(self, national_code):
        self._national_code = national_code


if __name__ == "__main__":
    human = Human()
    human.first_name = 'Mohammad'
    human.last_name = 'Nabati'
    human.age = 20
    human.national_code = "0018192603"
    print('Hello {} {} Your Age is {} and your national code is {}'
          .format(human.first_name, human.last_name, human.age, human.national_code))
