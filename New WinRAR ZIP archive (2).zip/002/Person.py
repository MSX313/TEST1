class Person:
    def __init__(self, first_name, last_name, date_of_birth, email, address):
        self.firstName = first_name
        self.lastName = last_name
        self.dateOfBirth = date_of_birth
        self.email = email
        self.address = address

    def display_info(self):
        print("Name: {} {}".format(self.firstName, self.lastName))
        print("Date of Birth: {}".format(self.dateOfBirth))
        print("Email: {}".format(self.email))
        print("Address: {}".format(self.address))

if __name__ == "__main__":
    sagharPerson = Person(
        first_name="Saghar",
        last_name="Bakhtiari",
        date_of_birth="1995-08-12",
        email="Saghar_bakhtiari@outlook.com",
        address="35 Main St, Saaeed Arab Teh"
    )
    sagharPerson.address = "456 Oak St, Townsville"
    sagharPerson.display_info()