class Car:
    def __init__(self, make, model, year, color):
        self.make = make
        self.model = model
        self.year = year
        self.color = color
        self.speed = 0
        self.is_engine_on = False

    def start_engine(self):
        if not self.is_engine_on:
            print("Starting the engine.")
            self.is_engine_on = True
        else:
            print("The engine is already running.")

    def stop_engine(self):
        if self.is_engine_on:
            print("Stopping the engine.")
            self.is_engine_on = False
            self.speed = 0
        else:
            print("The engine is already off.")

    def accelerate(self, mph):
        if self.is_engine_on:
            self.speed += mph
            print("Accelerating to {} mph.".format(self.speed))
        else:
            print("Cannot accelerate. The engine is off.")

    def brake(self):
        if self.speed > 0:
            print("Applying brakes.")
            self.speed = max(0, self.speed - 5)
            print("Current speed: {} mph.".format(self.speed))
        else:
            print("The car is already stationary.")

    def honk(self):
        print("Honk! Honk!")

    def display_info(self):
        print("Make: {}".format(self.make))
        print("Model: {}".format(self.model))
        print("Year: {}".format(self.year))
        print("Color: {}".format(self.color))
        print("Speed: {} mph".format(self.speed))
        print("Engine Status: {}".format("On" if self.is_engine_on else "Off"))


if __name__ == "__main__":
    my_car = Car(make="Toyota", model="Camry", year=2022, color="Blue")
    my_car.start_engine()
    my_car.accelerate(30)
    my_car.brake()
    my_car.stop_engine()
    my_car.display_info()
