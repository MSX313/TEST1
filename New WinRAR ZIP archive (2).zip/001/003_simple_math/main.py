from MathFunctions import *

if __name__ == "__main__":

    user_number = int(input("Enter a number: "))
    result = check_even_odd(user_number)
    print(f"The number {user_number} is {result}.")

    print("\nMultiplication Tables:")
    for i in range(2, 6):
        print_multiplication_table(i)

    factorial_number = int(input("\nEnter a number to calculate its factorial: "))
    if factorial_number < 0:
        print("Factorial is not defined for negative numbers.")
    else:
        result = calculate_factorial(factorial_number)
        print(f"The factorial of {factorial_number} is {result}.")