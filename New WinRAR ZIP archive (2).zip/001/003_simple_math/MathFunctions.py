def check_even_odd(number):
    if number % 2 == 0:
        return "Even"
    else:
        return "Odd"

def print_multiplication_table(n):
    print(f"Multiplication Table for {n}:")
    for i in range(1, 11):
        result = n * i
        print(f"{n} x {i} = {result}")

def calculate_factorial(num):
    factorial = 1
    for i in range(1, num + 1):
        factorial *= i
    return factorial