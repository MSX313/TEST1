print(10 <= 10)
print(bool(0 == 1))
print(18 > 5)
print('Jamila'.endswith('s'))
print('Jamila'.startswith('a'))
print('Jamila'.__contains__('am'))
print('hello'.startswith('o'))
print('hello'.startswith('O'))

x = 200
print(isinstance(x, int))