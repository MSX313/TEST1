cars = ['bmw', 'tesla', 'mercedes', 'toyota']
print(len(cars))
print(cars)
print(cars[0])
print(cars[1])
print(cars[2])
print(cars[3])
var = cars[3]
print(var)