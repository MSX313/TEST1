def check_age(age):
    if age < 18:
        print('oops not an adult')
    else:
        print('hooray I am an adult')

check_age(18)
check_age(17)
check_age(20)