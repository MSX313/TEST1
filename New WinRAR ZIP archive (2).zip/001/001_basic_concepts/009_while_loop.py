number = 0

while number <= 10:
    print(number)
    number = number + 1
else:
    print("while loop ended and value value of number is " + str(number))
