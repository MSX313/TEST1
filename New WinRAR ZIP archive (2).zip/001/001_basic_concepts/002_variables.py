from datetime import datetime, timedelta

name = 'Nana'
print(name)
age = 19
print(age)
pi = 3.14
print(pi)
cars = ['bmw','mercedes','range rover']
print(cars)

# *******************************************

first_name = str('danail')
print(type(first_name))
date_of_birth = "1992-11-13 08:30:00"
parsed_datetime = datetime.strptime(date_of_birth, "%Y-%m-%d %H:%M:%S")
print(parsed_datetime)
print(type(parsed_datetime))
