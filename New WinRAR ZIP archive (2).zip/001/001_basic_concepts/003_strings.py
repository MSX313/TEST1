first_name = 'nana'
sur_name = 'bakhtiari'
full_name = first_name.capitalize() + ' ' + sur_name.swapcase()

print(full_name)
print(len(full_name))