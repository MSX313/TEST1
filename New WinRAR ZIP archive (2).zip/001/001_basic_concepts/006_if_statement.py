is_adult = False
age = 17

if is_adult:
    print("is adult")

if age >= 18:
    print('adult')
else:
    print('not an adult')
