cars = ['bmw', 'tesla', 'mercedes', 'toyota']

for car in cars:
    if car == 'bmw':
        print(car.swapcase())
    elif car == 'tesla':
        print(car.capitalize())
    else:
        print(car.lower())