name = input('What is your name? ')
print('Hello ' + name)
