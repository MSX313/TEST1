package com.example.demo.model.entity.util.codes;

public interface FieldName {

    String ID = "C_ID";
    String INSERT_USER = "C_INSERT_USER";
    String UPDATE_USER = "C_UPDATE_USER";
    String INSERT_DATE_TIME = "C_INSERT_DATE_TIME";
    String UPDATE_DATE_TIME = "C_UPDATE_DATE_TIME";
    String VERSION = "C_VERSION";
    String IS_ACTIVE = "C_IS_ACTIVE";
    String USER_NAME = "C_USER_NAME";
    String PASSWORD = "C_PASSWORD";
    String NAME = "C_NAME";
    String ROLE_LIST = "roleList";
    String USER = "F_USER";
    String ROLE = "F_ROLE";
}