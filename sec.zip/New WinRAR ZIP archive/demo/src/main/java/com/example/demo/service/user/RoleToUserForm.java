package com.example.demo.service.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleToUserForm {

    private String userName;
    private String roleName;
}