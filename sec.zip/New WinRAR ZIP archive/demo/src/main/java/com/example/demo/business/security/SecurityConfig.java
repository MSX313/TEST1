package com.example.demo.business.security;

import com.example.demo.business.security.filter.CustomAuthenticationFilter;
import com.example.demo.business.security.filter.CustomAuthorizationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final UserDetailsService userDetailsService;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(bCryptPasswordEncoder);
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        // General
        // Cross-site request forgery (CSRF)
        // Cross-site request forgery (also known as CSRF) is a web security vulnerability that allows an attacker
        // to induce users to perform actions that they do not intend to perform. It allows an attacker to partly
        // circumvent the same origin policy, which is designed to prevent different websites from
        // interfering with each other.
        // https://portswigger.net/web-security/csrf
        httpSecurity.csrf().disable();
        httpSecurity.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        // Custom Authentication Filter
        CustomAuthenticationFilter authenticationFilter = new CustomAuthenticationFilter(authenticationManagerBean());
        authenticationFilter.setFilterProcessesUrl("/api/login");
        httpSecurity.addFilter(authenticationFilter);
        // Custom Authorization Filter
        CustomAuthorizationFilter authorizationFilter = new CustomAuthorizationFilter();
        httpSecurity.addFilterBefore(authorizationFilter, UsernamePasswordAuthenticationFilter.class);
    }

/*
http.authorizeRequests().antMatchers("/api/login/**", "/api/token/refresh").permitAll();
http.authorizeRequests().antMatchers(HttpMethod.GET, "/api/getUsers/**").hasAnyAuthority("USER");
http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/user/save/**").hasAnyAuthority("ADMIN");
http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/role/save/**").hasAnyAuthority("SUPER_ADMIN");
http.authorizeRequests().antMatchers(HttpMethod.POST, "/api/role/addToUser/**").hasAnyAuthority("MANAGER");
http.authorizeRequests().anyRequest().permitAll();
*/

}
