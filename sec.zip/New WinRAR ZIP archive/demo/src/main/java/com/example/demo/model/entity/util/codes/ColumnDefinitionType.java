package com.example.demo.model.entity.util.codes;

public interface ColumnDefinitionType {

    String NUMBER = "NUMBER";
    String VARCHAR_2_250 = "VARCHAR2(250)";
}