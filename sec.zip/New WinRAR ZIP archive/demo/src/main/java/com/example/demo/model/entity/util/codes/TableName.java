package com.example.demo.model.entity.util.codes;

public interface TableName {

    String USER = "T_SSC_USER_ENTITY";
    String ROLE = "T_SSC_ROLE_ENTITY";
    String JT_USER_ROLE = "T_SSC_USER_ROLE";
}