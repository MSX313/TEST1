package com.example.demo.model.entity.util.codes;

public interface SequenceName {

    String BASIC_ENTITY = "BASIC_ENTITY_SEQ";
}