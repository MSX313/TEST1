package com.example.demo.model.entity;

import com.example.demo.model.entity.util.BaseEntity;
import com.example.demo.model.entity.util.codes.ColumnDefinitionType;
import com.example.demo.model.entity.util.codes.EntityName;
import com.example.demo.model.entity.util.codes.FieldName;
import com.example.demo.model.entity.util.codes.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@RequiredArgsConstructor
@Getter
@Setter

@Entity(name = EntityName.ROLE)
@Table(name = TableName.ROLE)
public class Role extends BaseEntity {

    @Column(name = FieldName.NAME, columnDefinition = ColumnDefinitionType.VARCHAR_2_250, nullable = false)
    private String name;
    @ManyToMany(mappedBy = FieldName.ROLE_LIST, cascade = CascadeType.PERSIST)
    @JsonIgnore
    private List<User> userList;

    public Role(String name) {
        this.name = name;
    }
}