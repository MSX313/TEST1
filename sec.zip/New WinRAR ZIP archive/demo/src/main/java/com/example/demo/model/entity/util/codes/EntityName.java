package com.example.demo.model.entity.util.codes;

public interface EntityName {

    String USER = "user";
    String ROLE = "role";
}