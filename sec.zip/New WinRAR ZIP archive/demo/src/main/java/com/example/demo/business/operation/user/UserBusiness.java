package com.example.demo.business.operation.user;

import com.example.demo.model.entity.Role;
import com.example.demo.model.entity.User;

import java.util.List;

public interface UserBusiness {

    User saveUser(User user);

    Role saveRole(Role role);

    void addRoleToUser(String username, String roleName);

    User getUser(String userName);

    List<User> getUsers();
}