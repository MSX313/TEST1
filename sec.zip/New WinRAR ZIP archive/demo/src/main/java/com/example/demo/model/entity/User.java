package com.example.demo.model.entity;

import com.example.demo.model.entity.util.BaseEntity;
import com.example.demo.model.entity.util.codes.ColumnDefinitionType;
import com.example.demo.model.entity.util.codes.EntityName;
import com.example.demo.model.entity.util.codes.FieldName;
import com.example.demo.model.entity.util.codes.TableName;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Getter
@Setter

@Entity(name = EntityName.USER)
@Table(name = TableName.USER)
public class User extends BaseEntity {

    @Column(name = FieldName.NAME, columnDefinition = ColumnDefinitionType.VARCHAR_2_250, nullable = false)
    private String name;
    @Column(name = FieldName.USER_NAME, columnDefinition = ColumnDefinitionType.VARCHAR_2_250, nullable = false)
    private String userName;
    @Column(name = FieldName.PASSWORD, columnDefinition = ColumnDefinitionType.VARCHAR_2_250, nullable = false)
    private String password;
    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinTable(name = TableName.JT_USER_ROLE,
            joinColumns = @JoinColumn(name = FieldName.USER, referencedColumnName = FieldName.ID),
            inverseJoinColumns = @JoinColumn(name = FieldName.ROLE, referencedColumnName = FieldName.ID))
    private List<Role> roleList = new ArrayList<>();

    public User(String name, String userName, String password) {
        this.name = name;
        this.userName = userName;
        this.password = password;
    }

    public User(String name, String userName, String password, List<Role> roleList) {
        this.name = name;
        this.userName = userName;
        this.password = password;
        this.roleList = roleList;
    }
}