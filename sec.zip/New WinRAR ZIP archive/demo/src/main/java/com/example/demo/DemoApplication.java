package com.example.demo;

import com.example.demo.business.operation.user.UserBusiness;
import com.example.demo.model.entity.Role;
import com.example.demo.model.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

@SpringBootApplication
@Slf4j
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Transactional
    CommandLineRunner runner(UserBusiness userBusiness) {
        return args -> {

            Role role_user = new Role("USER");
            Role role_manger = new Role("MANAGER");
            Role role_admin = new Role("ADMIN");
            Role role_super_admin = new Role("SUPER_ADMIN");

            userBusiness.saveRole(role_user);
            userBusiness.saveRole(role_manger);
            userBusiness.saveRole(role_admin);
            userBusiness.saveRole(role_super_admin);

            User user_msx = new User("Mohammad Shahbandloo", "MSX", "123456");
            User user_shx = new User("Saeed Hamekare", "SHX", "123456");
            User user_aax = new User("Ahmad AramDel", "AAX", "123456");
            User user_sgx = new User("Sohrab Ghomarbaz", "SGX", "123456");

            userBusiness.saveUser(user_msx);
            userBusiness.saveUser(user_shx);
            userBusiness.saveUser(user_aax);
            userBusiness.saveUser(user_sgx);

            userBusiness.addRoleToUser("MSX", "SUPER_ADMIN");
            userBusiness.addRoleToUser("SHX", "USER");
            userBusiness.addRoleToUser("AAX", "ADMIN");
            userBusiness.addRoleToUser("AAX", "MANAGER");
            userBusiness.addRoleToUser("SGX", "USER");
            userBusiness.addRoleToUser("SGX", "MANAGER");
            userBusiness.addRoleToUser("SGX", "ADMIN");
        };
    }
}